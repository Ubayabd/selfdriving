# selfdriving-example
Simple self-driving example for [Valohai machine learning platform](https://valohai.com).

Based on Manajit Pal’s excellent [tutorial](https://towardsdatascience.com/deep-learning-for-self-driving-cars-7f198ef4cfa2) about Udacity's [self-driving car simulator](https://github.com/udacity/self-driving-car-sim)
